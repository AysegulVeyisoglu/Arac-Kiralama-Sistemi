﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AracKiralamaSistemi1.Startup))]
namespace AracKiralamaSistemi1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
